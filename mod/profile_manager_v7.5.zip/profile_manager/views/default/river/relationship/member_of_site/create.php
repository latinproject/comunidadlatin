<?php
/* site join event */
echo elgg_view('river/elements/layout', array(
	'item' => $vars['item'],
));